The Assignment class contains the main method whoch is the entry point. Input directory is traversed and java files are extracted in a list, then the removeDuplicates() method returns the unique java files. After this, the calculateResults() function is called iteratively for all the unique java files.

The executable .jar file is in the target folder..